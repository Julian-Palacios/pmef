## PMEF
## Programando el Método de Elementos Finitos

Códigos creados en Python en el año 2020 por Julian Palacios (jpalaciose@uni.pe)

Con la colaboración de:

Jorge Lulimachi (jlulimachis@uni.pe), 
Humberto Rojas (humberto.rojas.h@uni.pe), 
Luis Baldeon (luis.baldeon.c@uni.pe)

Cabe resaltar que este código se basó en las rutinas de matlab FEMCode realizado por Garth N .Wells (2005) para la clase CT5123 en TU Delft, Países Bajos.

PMEF es una librería desarrollada para enseñar a Programar el Método de Elementos Finitos mediante el curso online de JPI Ingeniería (www.jpi-ingenieria.com).
