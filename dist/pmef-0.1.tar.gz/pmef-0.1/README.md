## PMEF
## Programando el Método de Elementos Finitos en Python

Código creado en el año 2020 por Julian Palacios (jpalaciose@uni.pe)

Con la colaboración de Jorge Lulimachi (jlulimachis@uni.pe)

Codificado para la clase FICP-C811 en la UNI, Lima, Perú

Este código se basó en las rutinas de matlab FEMCode realizado inicialmente por Garth N .Wells (2005) para la clase CT5123 en TU Delft, Países Bajos
